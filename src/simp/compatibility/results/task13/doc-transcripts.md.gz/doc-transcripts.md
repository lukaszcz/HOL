## markerLib.ExclX
## `ExclX`

``` hol4
markerLib.ExclX : string -> thm
markerLib.destExclX : thm -> string option
```

------------------------------------------------------------------------

Constructs and recognizes the distinct extended-exclusion marker.

`ExclX name` constructs a hypothesis-free theorem with conclusion
`marker$ExcludeX v`, where `v` is a variable whose name is exactly the ML
string `name`. Like `Excl` and `ExclSF`, it stores names as variables, not
HOL string literals. No parsing, prefix encoding or target lookup occurs.
The theory constant is available as `marker$ExcludeX`; it introduces no
unqualified `ExcludeX` parser mapping, so unrelated variables and overloads
retain their meanings.

`destExclX th` returns `SOME name` for this conclusion and `NONE` otherwise.
It does not recognize legacy `Excl` or `ExclSF` markers; their recognizers
likewise reject `ExclX`. No legacy string is reserved to mean `ExclX`.

`markerLib.dest_directive (ExclX name)` returns
`SOME (markerLib.DExclX name)`. Requirement and bounded-rewrite wrappers
retain their usual precedence: `dest_directive` reports the outer wrapper
before the marker payload. `markerLib.strip_wrappers` exposes the marker.

### Simplifier routing

[`simpLib.ExclX`](#simpLib.ExclX) uses this marker for extended exclusions,
with explicit `rule:`, `looper:`, `solver:`, `split:` and `case:` namespaces.
Bare names use the strict legacy rule parser before strategy fallback;
all unmatched names, including bare ones, are errors when processed.
Literal legacy deletion remains available through `Excl`.

`Once` and `Ntimes` wrappers do not turn `ExclX` into bounded deletion:
it remains an invocation-wide control. Requirement wrappers retain their
usual precedence and checks. These are consumer semantics; constructing
or recognizing the marker does no target lookup and never fails for an
unmatched name.

Constructing or recognizing this marker does not enable persistent `split`
registration.

### Example

``` hol4
> val x = markerLib.ExclX "rule:Thy$Name";   ... output elided ...
> val SOME "rule:Thy$Name" = markerLib.destExclX x;
> val SOME (markerLib.DExclX "rule:Thy$Name") =
    markerLib.dest_directive x;
> val NONE = markerLib.destExcl x;
```

### See also

[`simpLib.Excl`](#simpLib.Excl),
[`simpLib.ExclX`](#simpLib.ExclX).

## simpLib.Excl
## `Excl`

``` hol4
simpLib.Excl : string -> thm
```

------------------------------------------------------------------------

Excludes named rewrites, conversions and decision procedures for one
invocation.

`Excl name` is a directive in the theorem list of a simplification
conversion or tactic. It uses exactly the same strict name parser and
rule deletion as `ss -* [name]`. Qualification uses dots, not the kernel
`Thy$Name` spelling:

- A name without dots is unqualified.
- A two-part dotted name with a numeric second part is also unqualified
  (for example, `name.1`). Otherwise its first part must be an ancestor
  theory; an unknown theory raises `bad theory name`.
- A three-part dotted name is read as `Thy.Name.suffix` without an
  ancestry check. More dots raise `User key has too many dots`.

Rewrites are matched by theory (if supplied) and name, including the
`rewrite:` prefix and generated dotted suffixes used by rewrite entries.
Named decision procedures are removed by exact string equality.

There is no namespace interpretation or strategy fallback: `rule:`,
`looper:`, `solver:`, `split:` and `case:` have no special meaning in an
`Excl` string. In particular, `Excl "bool$AND_CLAUSES"` does not exclude
the rewrite `bool.AND_CLAUSES`. Use [`simpLib.ExclX`](#simpLib.ExclX) for
extended exclusions.

An unmatched name is silent, but still records the same deletion history
as `-*`; it is not discarded just because no current rule matches.
Strict names are reparsed when that history is replayed, in the then-current
theory context (including after `Context.restore`). A later addition may
reinstall a deleted rule; this is not a prohibition on future additions.
Legacy clients require no migration. Only clients of the branch's earlier
extended namespace/fallback behavior should switch to `ExclX`.

### Failure

The constructor never fails. Processing the directive can fail for an
invalid name under the strict parser, just as `-*` can. Unmatched names
are not errors.

### Example

``` hol4
> SIMP_CONV bool_ss [Excl "bool$AND_CLAUSES"] “T ∧ p”;
val it = ⊢ T ∧ p ⇔ p: thm
> QCONV (SIMP_CONV bool_ss [Excl "bool.AND_CLAUSES"]) “T ∧ p”;
val it = ⊢ T ∧ p ⇔ T ∧ p: thm
```

### See also

[`simpLib.ExclX`](#simpLib.ExclX),
[`simpLib.SIMP_CONV`](#simpLib.SIMP_CONV),
[`simpLib.add_looper`](#simpLib.add_looper),
[`simpLib.add_unsafe_solver`](#simpLib.add_unsafe_solver),
[`simpLib.add_split`](#simpLib.add_split),
[`simpLib.split_ss`](#simpLib.split_ss).

## simpLib.ExclX
## `ExclX`

``` hol4
simpLib.ExclX : string -> thm
```

------------------------------------------------------------------------

Excludes named simplifier components for one invocation.

`ExclX name` is a directive in the theorem list of a simplification
conversion or tactic. Unlike literal [`simpLib.Excl`](#simpLib.Excl), it
resolves an exclusion target and supports explicit namespaces:

- `rule:name` excludes matching rewrites, conversions and named decision
  procedures.
  Rewrite names accept `Thy$Name` as well as dotted qualification, and
  the theory need not be an ancestor of the current theory. Numeric
  dotted suffixes retain their usual meaning; names with too many dots
  are still invalid. Decision procedures match the exact name string
  after `rule:`.
- `looper:name` excludes the ordinary looper named `name`.
- `solver:name` excludes the named solver from the safe and unsafe lists.
- `split:name` excludes the matching `split name` and `split_asm name`
  displays, including rules registered with the `split` attribute.
- `case:ty` excludes the datatype splits for `ty`, which may be an
  unqualified type operator or a kernel-qualified `Thy$Tyop`.

A bare name first goes through the same strict dots-only parser as
`Excl` and `-*`, including its ancestry check. A matching rewrite or
named decision procedure takes precedence over every strategy target.
Only if neither matches does lookup fall back to ordinary loopers,
solvers, split displays and case displays. Matching more than one of
these strategy kinds is an ambiguity error; use a namespace to select
the intended kind. Bare names cannot bypass strict parsing: use
`ExclX "case:bool"`, not `ExclX "split.case bool"`, whose dot invokes
the strict parser.

Every unmatched `ExclX` name is an error, including an unmatched bare
name. This differs from the silent unmatched deletion of `Excl` and `-*`.
Constructing a reusable conversion or tactic need not process the directive
until application. The supplied simpset is unchanged; exclusions affect only
the invocation. Constructing or processing this marker does not enable the
persistent `split` attribute. Local split rules and TypeBase targets remain
available without registration.

### History and repetition

`ss && [ExclX name]` records the exclusion in the resulting simpset's
history. Rule exclusions retain their resolved pattern, even for bare
names; unlike `Excl`, replay does not reparse them in the current theory.
Rule, ordinary looper and solver deletions act at that point in history:
a later addition can reinstall the target.

Split/case exclusions instead record suppression of the resolved displays,
including across fragment removal/replay and `Context.restore`. A later
local addition with the same excluded display remains suppressed. This is
local simpset state, not a persistent theorem-set REMOVE; use
`splitLib.exclude_split` for the latter.

Replaying suppression is idempotent, but a newly processed `ExclX` must
still resolve a target. Repeating a rule, ordinary looper or solver deletion
usually fails once its target is gone. Repeating a split/case exclusion
works while its ambient persistent/TypeBase target is still present; a
removed local-only split no longer matches.

`Once (ExclX name)` and `Ntimes (ExclX name) n` are still invocation-wide
controls, not bounded deletions: the bound does not count exclusions or
rewrite uses. Requirement wrappers (`Req0`, `ReqD`) retain their usual
precedence and checks; wrapping an exclusion does not bypass them.

### Failure

The constructor never fails: it stores the string without parsing or
looking up a target. Processing the directive can fail for an invalid
name, an ambiguous strategy target or any unmatched name.

### Example

``` hol4
> QCONV (SIMP_CONV bool_ss [simpLib.ExclX "rule:bool$AND_CLAUSES"])
    “T ∧ p”;
val it = ⊢ T ∧ p ⇔ T ∧ p: thm
> QCONV (SIMP_CONV bool_ss
    [Once (simpLib.ExclX "rule:bool$AND_CLAUSES")]) “T ∧ p”;
val it = ⊢ T ∧ p ⇔ T ∧ p: thm
```

### See also

[`simpLib.Excl`](#simpLib.Excl),
[`markerLib.ExclX`](#markerLib.ExclX),
[`simpLib.SIMP_CONV`](#simpLib.SIMP_CONV),
[`simpLib.add_looper`](#simpLib.add_looper),
[`simpLib.add_unsafe_solver`](#simpLib.add_unsafe_solver),
[`simpLib.add_split`](#simpLib.add_split),
[`simpLib.split_ss`](#simpLib.split_ss).

## simpLib.Split
## `Split`

``` hol4
simpLib.Split : thm -> thm
```

------------------------------------------------------------------------

Marks a theorem as a split rule for one simplifier call.

`Split th` in the theorem list of a simplifier call adds `th` to that
call's simpset as `add_split` does. A malformed rule is ignored with a
warning. This is a local rule: it requires no persistent registration and
neither claims the `split` attribute nor exports theorem-set data. Use the
ML constructor or the qualified `marker$Split` constant; no new unqualified
`Split` parser mapping is installed.

### Failure

Never fails.

### Example

``` hol4
> val c = Context.snapshot();
val c = ?: Context.t
> SIMP_TAC bool_ss [simpLib.Split (splitLib.type_split_of “:'a option”)]
    ([], “P (case x of NONE => 0 | SOME n => n + 1) : bool”) c;
val it = ([([], “(x = NONE ⇒ P 0) ∧ ∀x'. x = SOME x' ⇒ P (x' + 1)”)], fn):
   goal list * validation
```

### See also

[`simpLib.add_split`](#simpLib.add_split),
[`splitLib.SPLIT_TAC`](#splitLib.SPLIT_TAC),
[`simpLib.Cong`](#simpLib.Cong).

## simpLib.add_split
## `add_split`

``` hol4
simpLib.add_split : thm -> simpset -> simpset
```

------------------------------------------------------------------------

Adds a split rule to a simpset.

`add_split th ss` adds a looper applying `splitLib.SPLIT_TAC [th]`. The
looper is named `split name`, or `split_asm name` for an assumption
rule, where `name` is the database name of `th`, or `thy$c` if `th` is
unnamed and its redex has head constant `thy$c`. Adding a rule with the
same looper name replaces the old one. `ExclX "split:name"` disables the
rule for one call; see [`simpLib.ExclX`](#simpLib.ExclX).
This is local simpset state and needs no persistent split registration.
It does not add a theorem to the persistent `split` set.

### Failure

Fails if `th` is not a split rule.

### Example

``` hol4
> val c = Context.snapshot();
val c = ?: Context.t
> val opt_ss = simpLib.add_split (splitLib.type_split_of “:'a option”)
                 bool_ss;   ... output elided ...
> SIMP_TAC opt_ss []
    ([], “P (case x of NONE => 0 | SOME n => n + 1) : bool”) c;
val it = ([([], “(x = NONE ⇒ P 0) ∧ ∀x'. x = SOME x' ⇒ P (x' + 1)”)], fn):
   goal list * validation
> SIMP_TAC opt_ss [simpLib.ExclX "split:option$option_CASE"]
    ([], “P (case x of NONE => 0 | SOME n => n + 1) : bool”) c;
val it = ([([], “P (case x of NONE => 0 | SOME n => n + 1)”)], fn):
   goal list * validation
```

### See also

[`splitLib.SPLIT_TAC`](#splitLib.SPLIT_TAC),
[`simpLib.del_split`](#simpLib.del_split),
[`simpLib.Split`](#simpLib.Split),
[`simpLib.split_ss`](#simpLib.split_ss),
[`simpLib.add_looper`](#simpLib.add_looper).

## simpLib.del_split
## `del_split`

``` hol4
simpLib.del_split : string -> simpset -> simpset
```

------------------------------------------------------------------------

Removes split rules from a simpset.

`del_split name ss` removes the loopers `split name` and
`split_asm name` added by `add_split`; if `name` itself begins with
`split ` or `split_asm `, only that looper is removed. Rules with the
`split` attribute are unaffected; disable them for one call with
`ExclX ("split:" ^ name)`; see [`simpLib.ExclX`](#simpLib.ExclX).
To retract an attribute rule persistently for descendant replay, use
`splitLib.exclude_split "Thy.Name"` after explicit registration.
Local `del_split` never needs persistent registration.

### Failure

Never fails. Returns `ss` if no such looper exists.

### Example

``` hol4
> val c = Context.snapshot();
val c = ?: Context.t
> val opt_ss = simpLib.add_split (splitLib.type_split_of “:'a option”)
                 bool_ss;   ... output elided ...
> SIMP_TAC (simpLib.del_split "option$option_CASE" opt_ss) []
    ([], “P (case x of NONE => 0 | SOME n => n + 1) : bool”) c;
val it = ([([], “P (case x of NONE => 0 | SOME n => n + 1)”)], fn):
   goal list * validation
```

### See also

[`splitLib.exclude_split`](#splitLib.exclude_split),
[`simpLib.add_split`](#simpLib.add_split),
[`simpLib.split_ss`](#simpLib.split_ss).

## simpLib.split_ss
## `split_ss`

``` hol4
simpLib.split_ss : ssfrag
```

------------------------------------------------------------------------

Splits datatype case expressions and `split` rules during simplification.

`split_ss` is the fragment `"split"`. Its looper `"splitter"` applies
`splitLib.SPLIT_TAC` with the theorems of the current theory and its
ancestors that carry the `split` attribute (`Theorem name[split]: ...`,
which rejects malformed rules), after explicit
`splitLib.enable_split_attribute ()`, and the split rules of every datatype
whose case constant occurs fully applied in the goal. The fragment also
rewrites `(b ==> t) /\ (~b ==> t)` to `t`.

Loading this fragment does not register the attribute or theorem set.
Without explicit initialization it uses only TypeBase rules; local `Split`
rules also work without initialization. Initialization must precede data
replay when importing persistent split rules. Exporting theories explicitly
load `splitPersistLib` and record it with `Theory.add_ML_dependency` on the
earliest split-bearing theory; see `splitLib.enable_split_attribute` for
the script/import ordering recipe. Ancestor additions and persistent
`splitLib.exclude_split` removals are then replayed on fresh imports.

`ExclX "split:thy$name"` disables the attribute rule `thy$name` for one
call, and `ExclX "case:ty"` the rules of datatype `ty`; see
[`simpLib.ExclX`](#simpLib.ExclX).

### Failure

Never fails.

### Example

``` hol4
> val c = Context.snapshot();
val c = ?: Context.t
> SIMP_TAC (bool_ss ++ simpLib.split_ss) []
    ([], “P (if b then 1 else 2) : bool”) c;
val it = ([([], “(b ⇒ P 1) ∧ (¬b ⇒ P 2)”)], fn): goal list * validation
> SIMP_TAC (bool_ss ++ simpLib.split_ss) [simpLib.ExclX "case:bool"]
    ([], “P (if b then 1 else 2) : bool”) c;
val it = ([([], “P (if b then 1 else 2)”)], fn): goal list * validation
```

### See also

[`splitLib.enable_split_attribute`](#splitLib.enable_split_attribute),
[`splitLib.exclude_split`](#splitLib.exclude_split),
[`splitLib.SPLIT_TAC`](#splitLib.SPLIT_TAC),
[`simpLib.add_split`](#simpLib.add_split),
[`simpLib.del_split`](#simpLib.del_split),
[`simpLib.Split`](#simpLib.Split).

## simpLib.add_looper
## `add_looper`

``` hol4
simpLib.add_looper :
  string * (simpset -> tactic) -> simpset -> simpset
```

------------------------------------------------------------------------

Adds a named looper to a simpset.

A looper is a tactic that the simplification tactics apply to a goal
that rewriting and the final solvers leave open; see
[`simpLib.GEN_SIMP_TAC`](#simpLib.GEN_SIMP_TAC). In
`add_looper (name, mk) ss`, `mk` receives the simpset of the current
call and returns the tactic. Loopers are tried in the order they were
added. A new `name` is appended; an existing one has its tactic
replaced in place.

The tactic must fail when it does not apply (`Conv.UNCHANGED` counts as
failure) and make progress when it succeeds. `ExclX ("looper:" ^ name)`
in a theorem list disables the looper for that call. Bare `ExclX name`
first uses the strict rewrite-name parser and falls through to strategy
targets only when no rewrite or decision procedure matches; see
[`simpLib.ExclX`](#simpLib.ExclX).

### Failure

Never fails.

### Example

``` hol4
> val c = Context.snapshot();
val c = ?: Context.t
> val conj_ss = simpLib.add_looper ("conj", fn _ => CONJ_TAC) bool_ss;   ... output elided ...
> SIMP_TAC conj_ss [] ([], “p ∧ q”) c;
val it = ([([], “p”), ([], “q”)], fn): goal list * validation
> SIMP_TAC conj_ss [simpLib.ExclX "looper:conj"] ([], “p ∧ q”) c;
val it = ([([], “p ∧ q”)], fn): goal list * validation
```

### See also

[`simpLib.GEN_SIMP_TAC`](#simpLib.GEN_SIMP_TAC),
[`simpLib.del_looper`](#simpLib.del_looper),
[`simpLib.set_looper`](#simpLib.set_looper),
[`simpLib.looper_ss`](#simpLib.looper_ss),
[`simpLib.add_split`](#simpLib.add_split).

## simpLib.add_unsafe_solver
## `add_unsafe_solver`

``` hol4
simpLib.add_unsafe_solver : Traverse.ssolver -> simpset -> simpset
```

------------------------------------------------------------------------

Adds a named unsafe solver to a simpset.

A solver has type

``` hol4
type ssolver = {name : string, solve : simp_prover_ctxt -> term -> thm}
type simp_prover_ctxt =
  {stack : term list, context_thms : thm list, recurse : term -> thm}
```

`solve ctxt c` must prove `c` or raise `HOL_ERR`. In `ctxt`, `stack`
holds the side conditions being proved, `context_thms` the theorems in
scope (supplied theorems, assumptions and congruence-rule context), and
`recurse c` simplifies `c`, returning `|- c = c'`.

Unsafe solvers prove side conditions of conditional rewrites: once the
subgoaler has reduced a condition `c` to `c'` other than `T`, the unsafe
solvers are tried on `c'` in order. They are also the final solvers of
`GEN_SIMP_TAC {safe = false}`, and hence of `SIMP_TAC` and its
relatives.

`add_unsafe_solver solver ss` appends `solver` unless `ss` already has
an unsafe solver of the same name. `ExclX ("solver:" ^ name)` in a
theorem list disables the solver named `name` for that call. Bare
`ExclX name` first uses the strict rewrite-name parser and falls through
to strategy targets only when no rewrite or decision procedure matches;
see [`simpLib.ExclX`](#simpLib.ExclX).

### Failure

Never fails.

### Example

``` hol4
> val decide = {name = "decide", solve = K DECIDE} : Traverse.ssolver;
val decide = {name = "decide", solve = fn}: Traverse.ssolver
> SIMP_CONV bool_ss [arithmeticTheory.LESS_MOD] “x MOD (x + 1)”;
Exception- UNCHANGED raised
> SIMP_CONV (simpLib.add_unsafe_solver decide bool_ss)
    [arithmeticTheory.LESS_MOD] “x MOD (x + 1)”;
val it = ⊢ x MOD (x + 1) = x: thm
```

### See also

[`simpLib.GEN_SIMP_TAC`](#simpLib.GEN_SIMP_TAC),
[`simpLib.add_safe_solver`](#simpLib.add_safe_solver),
[`simpLib.set_unsafe_solvers`](#simpLib.set_unsafe_solvers),
[`simpLib.remove_solver`](#simpLib.remove_solver),
[`simpLib.solver_ss`](#simpLib.solver_ss),
[`simpLib.mk_tactic_solver`](#simpLib.mk_tactic_solver),
[`simpLib.set_subgoaler`](#simpLib.set_subgoaler).

## simpLib.traversedata_for_ss
## `traversedata_for_ss`

``` hol4
simpLib.traversedata_for_ss : simpset -> Traverse.traverse_data
```

------------------------------------------------------------------------

Extracts the legacy traversal description of a simpset. Its native rewriter
is a `Traverse.REDUCER`; supplied decision procedures retain their original
representation. The result carries equality as its relation and the
simpset's traversal rules and limit.

This projection omits simpset-specific subgoaler, unsafe solvers, condition
depth and term order. It is unconditional, including for simpsets rejected
by the optional dispatch accessor `legacy_traversedata_for_ss`.

Extraction does not invoke collectors, recompile installed rewrites or
reset their remaining bounded uses. The returned rewriter shares the
installed index, matchers and actual bounded controls. Subsequent traversal
construction and application retain the chosen Traverse entry point's
context lifetime: `Traverse.TRAVERSE data facts` initializes private reducer
contexts at conversion construction and reuses them on application.
The total `simpLib.SIMP_CONV` wrapper delays construction until application;
its lifetime must not be inferred from raw `TRAVERSE`.

For configured extraction, use `xtraversedata_for_ss ss` with the extended
Traverse entry points. Consumers needing only configured reducer data use
`#1 (xtraversedata_for_ss ss)` instead of this function.

### Failure

Extraction does not raise a simplification failure. Constructing or
applying the returned traversal can fail as for `Traverse.TRAVERSE`.

### Example

Legacy constructor inspection needs no opt-in:

``` hol4
> val data = simpLib.traversedata_for_ss simpLib.empty_ss;   ... output elided ...
> val Traverse.REDUCER _ = hd (#rewriters data);
> Traverse.TRAVERSE (simpLib.traversedata_for_ss bool_ss) [] “T ∧ p”;
val it = ⊢ T ∧ p ⇔ p: thm
```

### See also

[`simpLib.xtraversedata_for_ss`](#simpLib.xtraversedata_for_ss),
[`simpLib.legacy_traversedata_for_ss`](#simpLib.legacy_traversedata_for_ss).

## simpLib.xtraversedata_for_ss
## `xtraversedata_for_ss`

``` hol4
simpLib.xtraversedata_for_ss : simpset -> Traverse.xtraverse_data
```

------------------------------------------------------------------------

Extracts a configured traversal description, paired with the simpset's
subgoaler, unsafe solvers, condition depth and term order. Its native
rewriter is a `Traverse.CONFIG_REDUCER`; supplied decision procedures are
unchanged. The data carries equality as its relation and the simpset's
traversal rules and limit.

Pass the complete pair to extended Traverse entry points such as
`Traverse.XTRAVERSE`. Consumers needing configured reducer data alone use
`#1 (xtraversedata_for_ss ss)`. The public legacy accessor
`traversedata_for_ss` does not transport simpset-specific configuration and
returns a native `Traverse.REDUCER` instead.

Extraction invokes no collectors, does not recompile installed rewrites,
and does not reset bounded uses. Legacy and configured projections share
the actual installed bounded controls. `Traverse.XTRAVERSE pair facts`
refreshes private reducer contexts on each application, even with default
configuration. Raw `Traverse.TRAVERSE` initializes them at construction
instead. Taking `#1` discards the configuration; it does not make raw
`TRAVERSE` a configured runner or give it `XTRAVERSE`'s lifetime.

### Failure

Constructing or applying the returned traversal can fail as for the chosen
Traverse entry point.

### Example

Branch clients that previously expected configured public extraction use
this explicit accessor instead. Existing legacy clients need no migration.

``` hol4
> val ss = simpLib.set_cond_depth 2 bool_ss;   ... output elided ...
> val pair = simpLib.xtraversedata_for_ss ss;   ... output elided ...
> val Traverse.CONFIG_REDUCER _ = hd (#rewriters (#1 pair));
> Traverse.XTRAVERSE pair [] “T ∧ p”;
val it = ⊢ T ∧ p ⇔ p: thm
```

### See also

[`simpLib.traversedata_for_ss`](#simpLib.traversedata_for_ss),
[`simpLib.legacy_traversedata_for_ss`](#simpLib.legacy_traversedata_for_ss).

## simpLib.legacy_traversedata_for_ss
## `legacy_traversedata_for_ss`

``` hol4
simpLib.legacy_traversedata_for_ss :
  simpset -> Traverse.traverse_data option
```

------------------------------------------------------------------------

Returns an original-ABI traversal description when a simpset is eligible
for the ordinary simplifier execution path. This cooperation interface is
used by relation-aware consumers such as `congLib`.

The result is `NONE` if the simpset sets a subgoaler, nonempty unsafe solver
list, condition depth or term order, or contains a decision procedure other
than `Traverse.REDUCER`. Explicit settings remain configured even when equal
to their default values. Safe solvers and loopers are tactic-only settings
and do not prevent this projection.

Eligibility testing does not call user collectors or conversions. A `SOME`
result shares the installed rewrite index, prepared matchers and actual
bounded-rewrite controls. It neither recompiles installed rules nor resets
remaining uses. Supplying facts to `Traverse.TRAVERSE` still invokes its
collectors at conversion construction, as for other ordinary reducers.

A `SOME` result uses the same default builder as `traversedata_for_ss`:
its native rewriter is a `Traverse.REDUCER` and supplied decision procedures
are unchanged. Unlike this optional dispatch accessor, `traversedata_for_ss`
always returns that projection, even for ineligible inputs, omitting their
simpset-specific traversal configuration.

Use `xtraversedata_for_ss` for a configured native `CONFIG_REDUCER` paired
with the simpset's traversal configuration. Consumers needing configured
reducer data alone use `#1 (xtraversedata_for_ss ss)`. Both projections share
installed bounded controls. This does not imply identical storage usage or
measured performance.

### Failure

Eligibility inspection does not raise a simplification failure. Constructing
or applying the returned traversal can fail as for `Traverse.TRAVERSE`.

## splitLib.enable_split_attribute
## `enable_split_attribute`

``` hol4
splitLib.enable_split_attribute : unit -> unit
```

------------------------------------------------------------------------

Explicitly enables the persistent `split` attribute and theorem set.

Call this before using `Theorem name[split]: ...`, or before importing
split-bearing theories whose data must replay. Loading `splitLib` or
`simpLib` alone claims neither namespace. Initialization does not depend
on `simpLib`.

Repeated calls preserve the library's existing registration and rules.
Ownership and the data handle follow `Context.restore`. If either registry
has been replaced by a foreign owner, initialization fails rather than
replacing it. `splitLib.split_thms ()` and `named_split_thms ()` return
empty lists before initialization or under foreign ownership, without
registering anything or adopting foreign data.

Pure split conversions/tactics, local `Split`/`add_split` rules, and
TypeBase-driven `split_ss` do not need initialization.

### Failure

Fails before mutation if another owner has claimed either namespace, or
if `split` is reserved/an abbreviation. Also rejects foreign listeners
under its theory-data hook names, and new initialization inside a pinned
context (an already-owned registration is still a no-op).
Malformed rules supplied later to the attribute are rejected separately.

### Comments

For a fresh import, explicit initialization must execute before the
imported theory's data replay. An exporting script's call is not itself
serialized as import-time initialization. Use the explicit opt-in module
`splitPersistLib` in the earliest split-bearing script (before any `[split]`
declaration):

``` hol4
Theory mySplits[bare]
Libs
  HolKernel Parse boolLib splitLib splitPersistLib

val _ = Theory.add_ML_dependency "splitPersistLib"
```

`Libs` enables registration for the script; `add_ML_dependency` makes the
exported theory load the module before its data is decoded and replayed.
Put the dependency on the earliest split-bearing theory, not only a child:
parents load before a child's own ML dependencies. Descendant imports then
inherit additions and `splitLib.exclude_split` removals in fresh processes.
There is no implicit opt-in from ordinary `simpLib`/`splitLib` or queries.

Alternatively an explicit loader prelude may call this function before
loading the entire split-bearing theory graph. After `Context.restore`
to before registration, call this function again: the process-global ML
loader may already consider `splitPersistLib` loaded and not rerun its body.
Registration is serialized theory initialization, not a concurrent proof
operation. Arbitrary late/current-segment replay is not the supported
ordering contract.

### See also

[`splitLib.exclude_split`](#splitLib.exclude_split),
[`simpLib.split_ss`](#simpLib.split_ss),
[`splitLib.SPLIT_TAC`](#splitLib.SPLIT_TAC),
[`simpLib.Split`](#simpLib.Split).

## splitLib.exclude_split
## `exclude_split`

``` hol4
splitLib.exclude_split : string -> unit
```

------------------------------------------------------------------------

Persistently retracts a named split rule from the library-owned theorem set.

The argument is `"Thy.Name"`, or `"Name"` for the current theory. It is
resolved when written, not when a descendant replays it. For example,
`splitLib.exclude_split "mySplits.rule"` retracts that ancestor rule without
removing a descendant's identically named theorem. The key shown by
`named_split_thms` is the corresponding kernel name `"mySplits$rule"`;
use dot-qualified names, not display keys, as arguments to this function.

The operation updates the current persistent store and exports a REMOVE
for descendant replay. Retracting an absent name is harmless. It does not
delete the theorem from the database. Add rules with an explicitly enabled
`[split]` attribute. Initialization and fresh-import ordering are described
under `splitLib.enable_split_attribute`.

Unlike `simpLib.del_split` and `ExclX "split:Thy$Name"`, this is persistent
rather than an exclusion in a local simpset. It requires explicit, currently
library-owned registration and never initializes or adopts a foreign set.
Queries return no persistent rules before opt-in; local and TypeBase
splitting remain available without it.

### Failure

Fails without mutation if registration is absent or either namespace is
foreign-owned, or if the name is malformed. Also rejects retractions
inside a pinned context rather than writing to a different live context.

### See also

[`splitLib.enable_split_attribute`](#splitLib.enable_split_attribute),
[`simpLib.del_split`](#simpLib.del_split),
[`simpLib.split_ss`](#simpLib.split_ss).

## splitLib.SPLIT_TAC
## `SPLIT_TAC`

``` hol4
splitLib.SPLIT_TAC : thm list -> tactic
```

------------------------------------------------------------------------

Performs one case split with split rules. No persistent split registration
or call to `enable_split_attribute` is needed.

A split rule is a theorem without hypotheses of the form

``` hol4
|- !P ... . P (c a1 ... an) = rhs
```

where `P` is a Boolean-valued variable and `c` a constant. It is an
assumption rule if `rhs` is a negation, and a conclusion rule otherwise.
`splitLib.type_split_rules ty` gives both rules for the case constant of
datatype `ty`; `splitLib.type_split_of ty` gives the conclusion rule.

`SPLIT_TAC rules` rewrites the conclusion with one instance of a
conclusion rule: the matching redex under the fewest binders it depends
on, outermost and leftmost first, with `P` taken as the enclosing
formula. If no conclusion rule applies, it rewrites the first assumption
to which an assumption rule applies and strips the result, producing a
goal per case.

### Failure

Fails if a rule is malformed, or if no rule applies.

### Example

``` hol4
> val c = Context.snapshot();
val c = ?: Context.t
> splitLib.SPLIT_TAC [splitLib.type_split_of “:bool”]
    ([], “P (if b then 1 else 2) : bool”) c;
val it = ([([], “(b ⇒ P 1) ∧ (¬b ⇒ P 2)”)], fn): goal list * validation
> splitLib.SPLIT_TAC (splitLib.type_split_rules “:bool”)
    ([“P (if b then 1 else 2) : bool”], “Q : bool”) c;
val it = ([([“P 1”, “b”], “Q”), ([“P 2”, “¬b”], “Q”)], fn):
   goal list * validation
```

### Comments

To split on a chosen term throughout a goal, use `Cases_on` or
`CASE_TAC`.

### See also

[`simpLib.split_ss`](#simpLib.split_ss),
[`simpLib.add_split`](#simpLib.add_split),
[`simpLib.Split`](#simpLib.Split),
[`bossLib.Cases_on`](#bossLib.Cases_on),
[`BasicProvers.CASE_TAC`](#BasicProvers.CASE_TAC).
